#include "minishell.h"

int my_cd(char **args, t_node *node)
{
	// i beiliever when changing the derictory i should change pwd in env
	//since we have our own env, an we we will need it later in my_pwd;
	//NOTE : we need nodes here to;
	return (1);
}

int my_pwd(char **args, t_node  *node)
{
	//t_node *tmp;
	
	(void)node;
	(void)args;
	//tmp = node;
	// while(tmp->next != NULL)
	// {
	// 	if(ft_strcmp(tmp->name, "PWD") == 0)
	// 		printf("%s\n",tmp->val);
	// 	tmp = tmp->next;
	// }
	// if(ft_strcmp(tmp->name, "PWD") == 0)
	// 	printf("%s\n",tmp->val);
	printf("%s\n", getcwd(NULL, 0));
	//serch for pwd value in the lists of noedes send by the parser;
	// NOTE:i didn't use argument;
	return(1);
}

int my_env(char **args, t_node *node)
{
	t_node	*tmp;

	tmp = node;
	while(tmp->next != NULL)
	{
		printf("%s=",tmp->name);
		printf("%s",tmp->val);
		tmp = tmp->next;
	}
	printf("%s=",tmp->name);
	printf("%s",tmp->val);
	// just print the content of the list of nodes but you gonna need node as argument;
	//NOTE:i didn't use argument
	return(1);
}

int my_export(char **args,t_node *node)
{
	t_node	*tmp;
	char	*str;
	int		i;
	int     j;

	tmp = NULL;
	i = 0;
	str = NULL;
	while(args[j][i])
	{
		while(args[j][i] && args[j][i] != '=')
		{
			str[i] = args[j][i];
			i++;
		}
		if(args[j][i] == '=')
		{
			i++;
			j = 0;
			*tmp->name = *str;//not sure if it should be the address or the value;
			str = NULL;
			while(args[j][i])
			{
				str[j] = args[j][i];
				i++;
			}
			tmp->val = str;
			tmp->next = node;
			node->next = tmp;
		}

		else
			return(1);
		j++;
	}
	return(0);// not so sure about it;

	// i don't know wether we should do error management or not???????????
	
}

int my_unset(char **args,t_node *node)
{
	while(node)
	{
		
	}
	// if it needs the node argument it's ok, if not it's not gonna be with the first three at teh same
	//functions table;
	return (1);
}

int my_echo(char **args, t_node *node)
{
	int i;
	i = 1;
	if(!ft_strcmp(args[1], "-n"))
	{
		i = 2;
		while (args[i])
		{
			printf("%s ",args[i]);
			i++;
		}
	}
	else
	{
		while (args[i])
		{
			printf("%s ",args[i]);
			i++;
		}
		printf("\n");
	}
	return(1);
	//same for the above;
}

int my_exit(char **args, t_node *node)
{
	exit(0);
	return(1);
	// same for the above;
}
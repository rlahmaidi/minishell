int main(int ac, char **av, char **env)
{
	char *buf;
	while(1)
	{
		
		buf = readline("");
		printf("im'here");
		//printf("%s\n",buf);


	 }
	return(0);
}
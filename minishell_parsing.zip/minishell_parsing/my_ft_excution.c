#include "minishell.h"

void ft_excution(t_cmd *strct, t_node *node)
{
	int pid;
	FILE **fd;
	int i;

	// i = 0;
	// // open all the files but don't know why realllyy;
	// while(strct->redirections + i != NULL)
	// {
	// 	if(strct->redirections->type == '>')
	// 	 fd[i] = fopen("strct->redirections->arg","w");
	// 	else if(strct->redirections->type == '<')
	// 	 if(fd[i] = fopen("strct->redirections->arg","r") == NULL);
	// 	 // put a message wiht perror or something if the file dosn't exist ;
	// 	 else if(strct->redirections->type == '>>')
	// 	 fd[i] = fopen("strct->redirections->arg","a");
	// 	 i++;
	// }
	// //create a child process to excute the command in;
	// pid = fork();
	// if(pid == 0)
	// {
	// 	execve(strct->cmd,strct->args,node->name);
	// }
	// if(pid != 0)
	// 	 wait(pid);
	if (simple_non_builtin_cmd())
		execute_non_builtin();
	while (strct->next)
	{
		int fd[2];
		pipe(fd);

		int id = fork();
		if (id == 0)
		{
			dup2(); //
			ft_redirection();
			check_builtin(); // if (cmd == echo) echo(args)  || cmd == ...) 
			non_builtin(); //execve
		}
		final_cmd();
		strct = strct->next;
	}
}